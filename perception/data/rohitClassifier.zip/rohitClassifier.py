#!/usr/env/bin python

import cv2
###### Use only python2 libraries

class Classifier:
    def __init__(self):
        #Load Model

    def predictlabel(self, cv_image):
        '''
        Take a CV image and predit its label
        '''

        return label